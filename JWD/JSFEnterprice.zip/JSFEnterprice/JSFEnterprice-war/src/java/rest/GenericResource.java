/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rest;

import ejb.EmpBeanLocal;
import entity.EmpTB;
import java.util.Collection;
import javax.ejb.EJB;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.enterprise.context.RequestScoped;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

/**
 * REST Web Service
 *
 * @author shubham
 */
@Path("generic")
@RequestScoped
public class GenericResource {

    @EJB EmpBeanLocal el;
    @Context
    private UriInfo context;

    /**
     * Creates a new instance of GenericResource
     */
    public GenericResource() {
    }

    /**
     * Retrieves representation of an instance of rest.GenericResource
     * @return an instance of java.lang.String
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Collection<EmpTB> getEmps() {
       return el.getEmps();
    }
    
    @GET
    @Path("getSingleEmp")
    @Produces(MediaType.APPLICATION_JSON)
    public EmpTB getSingleEmp(@QueryParam("eid") int EmployeeId) {
       return el.getSingleEmployee(EmployeeId);
    }
    
    
    @POST
    @Path("AddEmp")

    @Consumes(MediaType.APPLICATION_JSON)
    public void AddEmp(@FormParam("ename")String EmployeeName,@FormParam("epass")String Password,@FormParam("edid")int DepartmentId,@FormParam("esal")int Salary){
        el.addEmp(EmployeeName, Password, DepartmentId, Salary);
        
    }
    
    @POST
    @Path("UpdateEmp")
    public void UpdateEmp(@FormParam("eid") int EmployeeId ,@FormParam("ename") String EmployeeName, @FormParam("pass") String Password,@FormParam("did") int DepartmentId,@FormParam("sal")int Salary){
        el.updateEmp(EmployeeId,EmployeeName, Password, DepartmentId, Salary);
        
    }
    
    @DELETE
    @Path("DeleteEmp")
    public void removeEmp(@QueryParam("eid") int EmployeeId){
        el.remove(EmployeeId);
    }

   
    @PUT
    @Consumes(MediaType.TEXT_HTML)
    public void putHtml(String content) {
    }
}
